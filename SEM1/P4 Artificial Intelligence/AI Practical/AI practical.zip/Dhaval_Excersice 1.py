#!/usr/bin/env python
# coding: utf-8

# "What is 7 to the power 4"

# In[1]:


7 ** 4


# ** Split this string:**
# 
# s = "Hi there Sam!"
# into a list.

# In[2]:


s= "Hi there sam!"


# In[3]:


s.split( )


# ** Given the variables:**
# 
# planet = "Earth"
# diameter = 12742
# ** Use .format() to print the following string: **
# 
# The diameter of Earth is 12742 kilometers.

# In[10]:


planet = "Earth"
diameter = 12742


# In[12]:


print("The diameter of {planet} is {diameter} kilometer.".format(planet=planet,diameter=diameter))


# In[ ]:




